﻿using System;

namespace TestCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayTest arrayTest = new ArrayTest();
            arrayTest.Test();
        }
    }
}
