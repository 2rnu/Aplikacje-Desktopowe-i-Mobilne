﻿namespace CollisionType
{
    internal class CollisionDetect
    {
    }
}